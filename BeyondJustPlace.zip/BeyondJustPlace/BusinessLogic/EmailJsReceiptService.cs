using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace BusinessLogic
{
    public class EmailJsReceiptService
    {
        private const string SendEndpoint = "https://api.emailjs.com/api/v1.0/email/send";

        public bool IsConfigured
        {
            get
            {
                return IsRealValue(GetSetting("EmailJsServiceId")) &&
                       IsRealValue(GetSetting("EmailJsTemplateId")) &&
                       IsRealValue(GetSetting("EmailJsPublicKey"));
            }
        }

        public async Task SendReceiptAsync(
            string toEmail,
            string guestName,
            string receiptNumber,
            string receiptHtml)
        {
            if (string.IsNullOrWhiteSpace(toEmail))
                throw new InvalidOperationException("The guest does not have an email address saved.");

            if (!IsConfigured)
                throw new InvalidOperationException(
                    "EmailJS is not configured yet. Add EmailJsServiceId, " +
                    "EmailJsTemplateId, and EmailJsPublicKey in App.config.");

            Dictionary<string, object> templateParams =
                new Dictionary<string, object>();

            templateParams["to_email"] = toEmail.Trim();
            templateParams["guest_name"] = guestName ?? "Guest";
            templateParams["receipt_number"] = receiptNumber ?? "Receipt";
            templateParams["hotel_name"] = GetSetting("HotelName", "Beyond Just Place");
            templateParams["receipt_html"] = receiptHtml ?? "";

            Dictionary<string, object> payload =
                new Dictionary<string, object>();

            payload["service_id"] = GetSetting("EmailJsServiceId");
            payload["template_id"] = GetSetting("EmailJsTemplateId");
            payload["user_id"] = GetSetting("EmailJsPublicKey");
            payload["template_params"] = templateParams;

            string privateKey = GetSetting("EmailJsPrivateKey");
            if (IsRealValue(privateKey))
                payload["accessToken"] = privateKey;

            JavaScriptSerializer serializer = new JavaScriptSerializer();
            string json = serializer.Serialize(payload);

            using (HttpClient client = new HttpClient())
            using (StringContent content =
                new StringContent(json, Encoding.UTF8, "application/json"))
            {
                HttpResponseMessage response =
                    await client.PostAsync(SendEndpoint, content);

                string responseBody = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    throw new InvalidOperationException(
                        "EmailJS failed (HTTP " +
                        ((int)response.StatusCode).ToString() + "): " +
                        responseBody);
                }
            }
        }

        private static string GetSetting(string key, string fallback = "")
        {
            string value = ConfigurationManager.AppSettings[key];
            return string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
        }

        private static bool IsRealValue(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return false;
            string upper = value.Trim().ToUpperInvariant();
            return !upper.StartsWith("YOUR_") &&
                   !upper.Contains("CHANGE_ME");
        }
    }
}
